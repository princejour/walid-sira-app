ملف مخصص للبناء إلى APK عبر GitHub Actions

المهم:
- لا ترفع هذا الملف المضغوط ZIP كما هو إلى GitHub.
- فكّ الضغط أولاً.
- ارفع محتويات المجلد الناتج كاملة إلى Repository.
- يجب أن تظهر في GitHub هذه العناصر في الصفحة الرئيسية:
  app
  .github
  build.gradle
  settings.gradle
  README_AR.txt

طريقة البناء:
1. بعد رفع الملفات اضغط Commit changes.
2. افتح تبويب Actions.
3. اختر Build Android APK.
4. اضغط Run workflow.
5. انتظر حتى تظهر علامة النجاح الخضراء.
6. افتح آخر عملية بناء.
7. من Artifacts حمّل: SiraMowathaba-debug-apk
8. ستجد داخلها ملف: app-debug.apk

هذا هو APK الجاهز للتنصيب على الهاتف.
